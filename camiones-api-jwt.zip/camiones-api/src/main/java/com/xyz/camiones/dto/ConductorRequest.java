package com.xyz.camiones.dto;

import jakarta.validation.constraints.NotBlank;

public record ConductorRequest(
        @NotBlank(message = "El nombre es obligatorio") String nombre,
        @NotBlank(message = "El apellido es obligatorio") String apellido,
        @NotBlank(message = "El numero de licencia es obligatorio") String numeroLicencia,
        @NotBlank(message = "El telefono es obligatorio") String telefono
) {
}
