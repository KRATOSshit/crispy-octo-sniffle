package com.xyz.camiones.service;

import com.xyz.camiones.dto.CamionRequest;
import com.xyz.camiones.dto.CamionResponse;
import com.xyz.camiones.dto.ConductorResumen;
import com.xyz.camiones.exception.BusinessException;
import com.xyz.camiones.exception.ResourceNotFoundException;
import com.xyz.camiones.model.Camion;
import com.xyz.camiones.repository.CamionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CamionService {

    private final CamionRepository camionRepository;

    public CamionService(CamionRepository camionRepository) {
        this.camionRepository = camionRepository;
    }

    @Transactional
    public CamionResponse registrar(CamionRequest request) {
        if (camionRepository.existsByPlaca(request.placa())) {
            throw new BusinessException("Ya existe un camion registrado con la placa " + request.placa());
        }
        Camion camion = new Camion();
        camion.setPlaca(request.placa());
        camion.setTipoVehiculo(request.tipoVehiculo());
        return toResponse(camionRepository.save(camion));
    }

    @Transactional(readOnly = true)
    public List<CamionResponse> listar() {
        return camionRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public CamionResponse obtener(Long id) {
        return toResponse(buscarOLanzar(id));
    }

    protected Camion buscarOLanzar(Long id) {
        return camionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el camion con id " + id));
    }

    protected CamionResponse toResponse(Camion camion) {
        ConductorResumen conductorResumen = camion.getConductor() == null ? null :
                new ConductorResumen(
                        camion.getConductor().getId(),
                        camion.getConductor().getNombre(),
                        camion.getConductor().getApellido(),
                        camion.getConductor().getNumeroLicencia()
                );
        return new CamionResponse(camion.getId(), camion.getPlaca(), camion.getTipoVehiculo(), conductorResumen);
    }
}
