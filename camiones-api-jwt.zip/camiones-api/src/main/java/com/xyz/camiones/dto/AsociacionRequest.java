package com.xyz.camiones.dto;

import jakarta.validation.constraints.NotNull;

public record AsociacionRequest(
        @NotNull(message = "El id del camion es obligatorio") Long camionId,
        @NotNull(message = "El id del conductor es obligatorio") Long conductorId
) {
}
