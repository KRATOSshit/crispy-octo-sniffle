package com.xyz.camiones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamionesApiApplicationTests {

    @Test
    void contextLoads() {
    }
}
