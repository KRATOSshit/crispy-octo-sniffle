package com.xyz.camiones.controller;

import com.xyz.camiones.dto.AsociacionRequest;
import com.xyz.camiones.dto.CamionResponse;
import com.xyz.camiones.service.AsociacionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/asociaciones")
public class AsociacionController {

    private final AsociacionService asociacionService;

    public AsociacionController(AsociacionService asociacionService) {
        this.asociacionService = asociacionService;
    }

    // Solo el SUPERVISOR puede asociar un conductor a un camion (regla: 1 conductor por camion).
    @PostMapping
    @PreAuthorize("hasRole('SUPERVISOR')")
    public ResponseEntity<CamionResponse> asociar(@Valid @RequestBody AsociacionRequest request) {
        return ResponseEntity.ok(asociacionService.asociar(request));
    }

    // Permite liberar el conductor de un camion (tambien restringido al SUPERVISOR).
    @DeleteMapping("/{camionId}")
    @PreAuthorize("hasRole('SUPERVISOR')")
    public ResponseEntity<CamionResponse> desasociar(@PathVariable Long camionId) {
        return ResponseEntity.ok(asociacionService.desasociar(camionId));
    }
}
