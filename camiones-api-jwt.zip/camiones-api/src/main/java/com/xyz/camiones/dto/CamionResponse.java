package com.xyz.camiones.dto;

public record CamionResponse(
        Long id,
        String placa,
        String tipoVehiculo,
        ConductorResumen conductor
) {
}
