package com.xyz.camiones.dto;

public record ConductorResponse(
        Long id,
        String nombre,
        String apellido,
        String numeroLicencia,
        String telefono
) {
}
