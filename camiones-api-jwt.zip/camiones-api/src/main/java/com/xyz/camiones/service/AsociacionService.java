package com.xyz.camiones.service;

import com.xyz.camiones.dto.AsociacionRequest;
import com.xyz.camiones.dto.CamionResponse;
import com.xyz.camiones.exception.BusinessException;
import com.xyz.camiones.exception.ResourceNotFoundException;
import com.xyz.camiones.model.Camion;
import com.xyz.camiones.model.Conductor;
import com.xyz.camiones.repository.CamionRepository;
import com.xyz.camiones.repository.ConductorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AsociacionService {

    private final CamionRepository camionRepository;
    private final ConductorRepository conductorRepository;
    private final CamionService camionService;

    public AsociacionService(CamionRepository camionRepository,
                              ConductorRepository conductorRepository,
                              CamionService camionService) {
        this.camionRepository = camionRepository;
        this.conductorRepository = conductorRepository;
        this.camionService = camionService;
    }

    /**
     * Asocia un conductor a un camion. Regla de negocio: solo 1 conductor por camion.
     * Ademas se valida que ese conductor no este ya asociado a otro camion distinto.
     */
    @Transactional
    public CamionResponse asociar(AsociacionRequest request) {
        Camion camion = camionRepository.findById(request.camionId())
                .orElseThrow(() -> new ResourceNotFoundException("No existe el camion con id " + request.camionId()));

        Conductor conductor = conductorRepository.findById(request.conductorId())
                .orElseThrow(() -> new ResourceNotFoundException("No existe el conductor con id " + request.conductorId()));

        if (camion.getConductor() != null && !camion.getConductor().getId().equals(conductor.getId())) {
            throw new BusinessException("El camion " + camion.getPlaca()
                    + " ya tiene un conductor asociado. Debe desasociarlo antes de asignar uno nuevo.");
        }

        camionRepository.findByConductorId(conductor.getId())
                .filter(otroCamion -> !otroCamion.getId().equals(camion.getId()))
                .ifPresent(otroCamion -> {
                    throw new BusinessException("El conductor ya esta asociado al camion con placa " + otroCamion.getPlaca());
                });

        camion.setConductor(conductor);
        return camionService.toResponse(camionRepository.save(camion));
    }

    @Transactional
    public CamionResponse desasociar(Long camionId) {
        Camion camion = camionRepository.findById(camionId)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el camion con id " + camionId));
        camion.setConductor(null);
        return camionService.toResponse(camionRepository.save(camion));
    }
}
