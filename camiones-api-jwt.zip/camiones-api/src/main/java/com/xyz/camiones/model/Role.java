package com.xyz.camiones.model;

public enum Role {
    ADMINISTRADOR,
    SUPERVISOR
}
