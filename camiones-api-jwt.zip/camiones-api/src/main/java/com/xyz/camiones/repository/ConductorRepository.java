package com.xyz.camiones.repository;

import com.xyz.camiones.model.Conductor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConductorRepository extends JpaRepository<Conductor, Long> {

    boolean existsByNumeroLicencia(String numeroLicencia);
}
