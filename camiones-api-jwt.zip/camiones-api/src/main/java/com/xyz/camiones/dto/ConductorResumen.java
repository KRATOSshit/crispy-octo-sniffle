package com.xyz.camiones.dto;

public record ConductorResumen(
        Long id,
        String nombre,
        String apellido,
        String numeroLicencia
) {
}
