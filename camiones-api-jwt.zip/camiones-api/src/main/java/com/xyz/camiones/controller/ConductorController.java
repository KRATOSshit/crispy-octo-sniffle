package com.xyz.camiones.controller;

import com.xyz.camiones.dto.ConductorRequest;
import com.xyz.camiones.dto.ConductorResponse;
import com.xyz.camiones.service.ConductorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/conductores")
public class ConductorController {

    private final ConductorService conductorService;

    public ConductorController(ConductorService conductorService) {
        this.conductorService = conductorService;
    }

    // Solo el ADMINISTRADOR puede registrar conductores.
    @PostMapping
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public ResponseEntity<ConductorResponse> registrar(@Valid @RequestBody ConductorRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(conductorService.registrar(request));
    }

    // Consulta disponible para ambos roles (requiere autenticacion, no es publico).
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMINISTRADOR', 'SUPERVISOR')")
    public ResponseEntity<List<ConductorResponse>> listar() {
        return ResponseEntity.ok(conductorService.listar());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMINISTRADOR', 'SUPERVISOR')")
    public ResponseEntity<ConductorResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(conductorService.obtener(id));
    }
}
