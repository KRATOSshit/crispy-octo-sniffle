package com.xyz.camiones.repository;

import com.xyz.camiones.model.Camion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CamionRepository extends JpaRepository<Camion, Long> {

    boolean existsByPlaca(String placa);

    Optional<Camion> findByConductorId(Long conductorId);
}
