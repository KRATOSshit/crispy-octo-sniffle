package com.xyz.camiones.controller;

import com.xyz.camiones.dto.CamionRequest;
import com.xyz.camiones.dto.CamionResponse;
import com.xyz.camiones.service.CamionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/camiones")
public class CamionController {

    private final CamionService camionService;

    public CamionController(CamionService camionService) {
        this.camionService = camionService;
    }

    // Solo el ADMINISTRADOR puede registrar camiones.
    @PostMapping
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public ResponseEntity<CamionResponse> registrar(@Valid @RequestBody CamionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(camionService.registrar(request));
    }

    // Consulta disponible para ambos roles (requiere autenticacion, no es publico).
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMINISTRADOR', 'SUPERVISOR')")
    public ResponseEntity<List<CamionResponse>> listar() {
        return ResponseEntity.ok(camionService.listar());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMINISTRADOR', 'SUPERVISOR')")
    public ResponseEntity<CamionResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(camionService.obtener(id));
    }
}
