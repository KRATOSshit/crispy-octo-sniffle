package com.xyz.camiones.service;

import com.xyz.camiones.dto.ConductorRequest;
import com.xyz.camiones.dto.ConductorResponse;
import com.xyz.camiones.exception.BusinessException;
import com.xyz.camiones.exception.ResourceNotFoundException;
import com.xyz.camiones.model.Conductor;
import com.xyz.camiones.repository.ConductorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ConductorService {

    private final ConductorRepository conductorRepository;

    public ConductorService(ConductorRepository conductorRepository) {
        this.conductorRepository = conductorRepository;
    }

    @Transactional
    public ConductorResponse registrar(ConductorRequest request) {
        if (conductorRepository.existsByNumeroLicencia(request.numeroLicencia())) {
            throw new BusinessException("Ya existe un conductor registrado con la licencia " + request.numeroLicencia());
        }
        Conductor conductor = new Conductor();
        conductor.setNombre(request.nombre());
        conductor.setApellido(request.apellido());
        conductor.setNumeroLicencia(request.numeroLicencia());
        conductor.setTelefono(request.telefono());
        return toResponse(conductorRepository.save(conductor));
    }

    @Transactional(readOnly = true)
    public List<ConductorResponse> listar() {
        return conductorRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public ConductorResponse obtener(Long id) {
        return toResponse(buscarOLanzar(id));
    }

    protected Conductor buscarOLanzar(Long id) {
        return conductorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el conductor con id " + id));
    }

    private ConductorResponse toResponse(Conductor conductor) {
        return new ConductorResponse(conductor.getId(), conductor.getNombre(), conductor.getApellido(),
                conductor.getNumeroLicencia(), conductor.getTelefono());
    }
}
