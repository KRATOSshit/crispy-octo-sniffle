# Camiones API — Empresa XYZ

API REST en **Java 17 + Spring Boot 3** para el registro de camiones, conductores
y su asociación, cumpliendo los requisitos de la actividad:

- Dos roles: **ADMINISTRADOR** y **SUPERVISOR**.
- El **ADMINISTRADOR** registra camiones (placa, tipo de vehículo) y conductores.
- El **SUPERVISOR** solo puede asociar un conductor a un camión (**1 conductor por camión**).
- El sistema es un **API REST completamente asegurado**: no existe ningún
  endpoint público, todas las rutas requieren autenticación (HTTP Basic +
  Spring Security) y autorización por rol.

## Stack técnico

| Componente        | Detalle                                      |
|-------------------|-----------------------------------------------|
| Lenguaje          | Java 17                                       |
| Framework         | Spring Boot 3.3.2                             |
| Seguridad         | Spring Security (HTTP Basic, BCrypt, stateless, `@PreAuthorize`) |
| Persistencia      | Spring Data JPA + H2 (en memoria)             |
| Validación        | Bean Validation (`jakarta.validation`)        |
| Build              | Maven                                          |

## Estructura del proyecto

```
src/main/java/com/xyz/camiones
├── config/           SecurityConfig, DataInitializer (usuarios semilla)
├── controller/        CamionController, ConductorController, AsociacionController
├── dto/               Records de entrada/salida (validación incluida)
├── exception/         Excepciones de negocio + manejador global (JSON)
├── model/             Entidades JPA: Usuario, Camion, Conductor, Role
├── repository/        Interfaces Spring Data JPA
└── service/           Lógica de negocio y reglas de asociación
```

## Cómo ejecutar

```bash
mvn spring-boot:run
```

La aplicación queda disponible en `http://localhost:8080`. Al arrancar,
`DataInitializer` crea automáticamente dos usuarios de prueba (si no existen):

| Usuario      | Password        | Rol            |
|--------------|-----------------|----------------|
| `admin`      | `Admin123*`     | ADMINISTRADOR  |
| `supervisor` | `Supervisor123*`| SUPERVISOR     |

> En producción estas credenciales deben cambiarse / gestionarse por fuera del código.

## Seguridad

- **Sin endpoints públicos**: `anyRequest().authenticated()` cubre absolutamente
  todas las rutas, incluida la raíz. No hay Actuator ni consola H2 expuesta.
- **HTTP Basic** sobre **sesión stateless** (no se guarda sesión en servidor,
  cada request se autentica con el header `Authorization: Basic ...`).
- **Contraseñas** almacenadas con **BCrypt**, nunca en texto plano.
- **Autorización por rol** aplicada método a método con `@PreAuthorize`, así que
  aunque alguien esté autenticado, solo puede ejecutar las operaciones de su rol.

## Reglas de negocio implementadas

1. Un camión no puede registrarse con una placa ya existente.
2. Un conductor no puede registrarse con un número de licencia ya existente.
3. **Un camión solo puede tener un conductor asociado a la vez** (si ya tiene uno,
   hay que desasociarlo antes de asignar otro).
4. **Un conductor solo puede estar asociado a un camión a la vez** (se valida en el
   servicio y además queda garantizado a nivel de base de datos con una restricción
   `UNIQUE` sobre la columna `conductor_id`).

## Endpoints

| Método | Ruta                       | Rol requerido            | Descripción                              |
|--------|----------------------------|---------------------------|-------------------------------------------|
| POST   | `/api/camiones`            | ADMINISTRADOR              | Registrar un camión                       |
| GET    | `/api/camiones`            | ADMINISTRADOR o SUPERVISOR | Listar camiones                           |
| GET    | `/api/camiones/{id}`       | ADMINISTRADOR o SUPERVISOR | Consultar un camión                       |
| POST   | `/api/conductores`         | ADMINISTRADOR              | Registrar un conductor                    |
| GET    | `/api/conductores`         | ADMINISTRADOR o SUPERVISOR | Listar conductores                        |
| GET    | `/api/conductores/{id}`    | ADMINISTRADOR o SUPERVISOR | Consultar un conductor                    |
| POST   | `/api/asociaciones`        | SUPERVISOR                 | Asociar un conductor a un camión          |
| DELETE | `/api/asociaciones/{id}`   | SUPERVISOR                 | Desasociar el conductor de un camión      |

Todas las rutas exigen el header `Authorization: Basic ...`; sin credenciales
válidas la API responde `401 Unauthorized`, y con un rol incorrecto responde
`403 Forbidden`.

## Ejemplos con `curl`

**1. Registrar un camión (ADMINISTRADOR):**

```bash
curl -u admin:Admin123* -X POST http://localhost:8080/api/camiones \
  -H "Content-Type: application/json" \
  -d '{"placa": "ABC123", "tipoVehiculo": "Camión de carga"}'
```

**2. Registrar un conductor (ADMINISTRADOR):**

```bash
curl -u admin:Admin123* -X POST http://localhost:8080/api/conductores \
  -H "Content-Type: application/json" \
  -d '{"nombre": "Juan", "apellido": "Pérez", "numeroLicencia": "LIC001", "telefono": "3001234567"}'
```

**3. Asociar conductor a camión (SUPERVISOR):**

```bash
curl -u supervisor:Supervisor123* -X POST http://localhost:8080/api/asociaciones \
  -H "Content-Type: application/json" \
  -d '{"camionId": 1, "conductorId": 1}'
```

**4. Intentar registrar un camión como SUPERVISOR (debe fallar con 403):**

```bash
curl -u supervisor:Supervisor123* -X POST http://localhost:8080/api/camiones \
  -H "Content-Type: application/json" \
  -d '{"placa": "XYZ999", "tipoVehiculo": "Furgón"}'
```

**5. Consultar sin credenciales (debe fallar con 401):**

```bash
curl -X GET http://localhost:8080/api/camiones
```

## Notas de diseño

- Se usa `record` de Java para los DTOs (inmutables, con validación integrada
  vía `jakarta.validation`), separando siempre el modelo de persistencia del
  contrato expuesto por el API.
- Un `@RestControllerAdvice` centraliza el manejo de errores devolviendo un
  JSON consistente (`timestamp`, `status`, `error`, `message`) para errores de
  validación, reglas de negocio, recursos no encontrados y accesos denegados.
- La base de datos es H2 en memoria para facilitar la ejecución y pruebas
  locales sin instalar nada adicional; puede cambiarse por PostgreSQL/MySQL
  ajustando únicamente `application.yml` y la dependencia del driver en el `pom.xml`.
