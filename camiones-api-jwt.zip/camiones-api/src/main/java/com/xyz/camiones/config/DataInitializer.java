package com.xyz.camiones.config;

import com.xyz.camiones.model.Camion;
import com.xyz.camiones.model.Conductor;
import com.xyz.camiones.model.Role;
import com.xyz.camiones.model.Usuario;
import com.xyz.camiones.repository.CamionRepository;
import com.xyz.camiones.repository.ConductorRepository;
import com.xyz.camiones.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Crea, al arrancar la aplicacion:
 *  1. Los usuarios de prueba (uno por rol), si aun no existen.
 *  2. Unos datos de fabrica (camiones y conductores) para que la API no
 *     arranque vacia y se pueda demostrar de inmediato la consulta, el
 *     registro de nuevos elementos y la asociacion conductor-camion.
 *
 * En un entorno real estas credenciales/datos se gestionarian aparte;
 * aqui se dejan fijos unicamente para poder probar el API de inmediato.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final CamionRepository camionRepository;
    private final ConductorRepository conductorRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UsuarioRepository usuarioRepository,
                            CamionRepository camionRepository,
                            ConductorRepository conductorRepository,
                            PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.camionRepository = camionRepository;
        this.conductorRepository = conductorRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        crearUsuarioSiNoExiste("admin", "Admin123*", Role.ADMINISTRADOR);
        crearUsuarioSiNoExiste("supervisor", "Supervisor123*", Role.SUPERVISOR);
        crearDatosDeFabrica();
    }

    private void crearUsuarioSiNoExiste(String username, String rawPassword, Role role) {
        if (!usuarioRepository.existsByUsername(username)) {
            Usuario usuario = new Usuario();
            usuario.setUsername(username);
            usuario.setPassword(passwordEncoder.encode(rawPassword));
            usuario.setRole(role);
            usuario.setEnabled(true);
            usuarioRepository.save(usuario);
        }
    }

    /**
     * Siembra datos de ejemplo solo la primera vez que arranca la app
     * (si ya hay camiones registrados, no vuelve a insertar nada).
     *
     * A proposito se deja UN camion y UN conductor sin asociar, para que
     * el usuario pueda probar el endpoint POST /api/asociaciones (rol
     * SUPERVISOR) con datos reales sin tener que registrar nada antes.
     */
    private void crearDatosDeFabrica() {
        if (camionRepository.count() > 0) {
            return;
        }

        Conductor carlos = nuevoConductor("Carlos", "Gómez", "LIC-1001", "3001112233");
        Conductor maria = nuevoConductor("María", "Rodríguez", "LIC-1002", "3002223344");
        Conductor andres = nuevoConductor("Andrés", "Torres", "LIC-1003", "3003334455");
        conductorRepository.saveAll(List.of(carlos, maria, andres));

        Camion furgon = nuevoCamion("WZP123", "Furgón refrigerado");
        Camion doble = nuevoCamion("TRK456", "Camión doble troque");
        Camion camioneta = nuevoCamion("VAN789", "Camioneta de reparto");

        // Estos dos quedan asociados de fábrica...
        furgon.setConductor(carlos);
        doble.setConductor(maria);
        // ...y "camioneta" + "andres" quedan libres a propósito, para que
        // el SUPERVISOR pueda demostrar la asociación con datos reales.

        camionRepository.saveAll(List.of(furgon, doble, camioneta));
    }

    private Conductor nuevoConductor(String nombre, String apellido, String numeroLicencia, String telefono) {
        Conductor conductor = new Conductor();
        conductor.setNombre(nombre);
        conductor.setApellido(apellido);
        conductor.setNumeroLicencia(numeroLicencia);
        conductor.setTelefono(telefono);
        return conductor;
    }

    private Camion nuevoCamion(String placa, String tipoVehiculo) {
        Camion camion = new Camion();
        camion.setPlaca(placa);
        camion.setTipoVehiculo(tipoVehiculo);
        return camion;
    }
}
