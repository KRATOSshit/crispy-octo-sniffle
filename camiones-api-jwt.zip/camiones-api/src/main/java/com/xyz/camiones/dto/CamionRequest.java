package com.xyz.camiones.dto;

import jakarta.validation.constraints.NotBlank;

public record CamionRequest(
        @NotBlank(message = "La placa es obligatoria") String placa,
        @NotBlank(message = "El tipo de vehiculo es obligatorio") String tipoVehiculo
) {
}
